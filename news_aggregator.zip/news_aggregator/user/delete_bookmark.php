<?php
session_start();
include('../config/config.php');

if (!isset($_SESSION['user_id'])) {
    die("<script>alert('You must log in to delete bookmarks!'); window.location.href='../auth/login.php';</script>");
}

$bookmark_id = $_POST['id'];
$query = "DELETE FROM bookmarks WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $bookmark_id);

if ($stmt->execute()) {
    echo "<script>alert('Bookmark deleted!'); window.location.href='bookmarks.php';</script>";
} else {
    echo "<script>alert('Failed to delete. Try again!'); window.history.back();</script>";
}
?>
