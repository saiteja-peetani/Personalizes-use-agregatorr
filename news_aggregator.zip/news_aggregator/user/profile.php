<?php
require '../config/db.php';
session_start();

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Fetch current user data
$stmt = $conn->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $email);
$stmt->fetch();
$stmt->close();

// Handle profile update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = trim($_POST["username"]);
    $new_email = trim($_POST["email"]);
    $new_password = $_POST["password"] ? password_hash($_POST["password"], PASSWORD_DEFAULT) : null;

    // Check if email is already in use
    $check_email = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
    $check_email->bind_param("si", $new_email, $user_id);
    $check_email->execute();
    $check_email->store_result();

    if ($check_email->num_rows > 0) {
        $message = "⚠️ Email already exists!";
    } else {
        // Update user data
        if ($new_password) {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?");
            $stmt->bind_param("sssi", $new_username, $new_email, $new_password, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
            $stmt->bind_param("ssi", $new_username, $new_email, $user_id);
        }

        if ($stmt->execute()) {
            $_SESSION['username'] = $new_username;  // Update session username
            $message = "✅ Profile updated successfully!";
        } else {
            $message = "⚠️ Update failed!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Profile - News Aggregator</title>
    <link rel="stylesheet" href="../templates/styles.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<?php include '../templates/header.php'; ?>

<div class="container mt-4">
    <h2>👤 Update Profile</h2>
    <p class="text-danger"><?php echo $message; ?></p>
    <form method="POST">
        <input type="text" class="form-control" name="username" value="<?php echo $username; ?>" required><br>
        <input type="email" class="form-control" name="email" value="<?php echo $email; ?>" required><br>
        <input type="password" class="form-control" name="password" placeholder="New Password (leave blank to keep old)" ><br>
        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

<?php include '../templates/footer.php'; ?>

</body>
</html>
