<?php
session_start();
include('../config/config.php');

if (!isset($_SESSION['user_id'])) {
    die("<script>alert('You must log in to bookmark articles!'); window.location.href='../auth/login.php';</script>");
}

$user_id = $_SESSION['user_id'];
$title = $_POST['title'];
$description = $_POST['description'];
$url = $_POST['url'];
$image_url = $_POST['image_url'];
$published_at = $_POST['published_at'];

// Check if already bookmarked
$checkQuery = "SELECT * FROM bookmarks WHERE user_id = ? AND url = ?";
$stmt = $conn->prepare($checkQuery);
$stmt->bind_param("is", $user_id, $url);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    die("<script>alert('Already bookmarked!'); window.history.back();</script>");
}

// Insert into bookmarks table
$query = "INSERT INTO bookmarks (user_id, title, description, url, image_url, published_at) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("isssss", $user_id, $title, $description, $url, $image_url, $published_at);

if ($stmt->execute()) {
    echo "<script>alert('Bookmarked successfully!'); window.history.back();</script>";
} else {
    echo "<script>alert('Failed to bookmark. Try again!'); window.history.back();</script>";
}
?>
