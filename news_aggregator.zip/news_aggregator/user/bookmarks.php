<?php
session_start();
include "../config/db.php"; 

if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT * FROM bookmarks WHERE user_id = ?");
$query->bind_param("i", $user_id);
$query->execute();
$result = $query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>My Bookmarks</title>
    <link rel="stylesheet" href="../templates/styles.css">
</head>
<body>
    <?php include "../templates/header.php"; ?>
    <div class="container">
        <h2>📌 My Bookmarks</h2>
        <div class="row">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="col-md-4">
                    <div class="card">
                        <img src="<?= $row['article_image']; ?>" class="card-img-top">
                        <div class="card-body">
                            <h5 class="card-title"><?= $row['article_title']; ?></h5>
                            <p class="card-text">Source: <?= $row['article_source']; ?></p>
                            <a href="<?= $row['article_url']; ?>" class="btn btn-primary" target="_blank">Read More</a>
                            <button class="btn btn-danger remove-bookmark" data-url="<?= $row['article_url']; ?>">Remove</button>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
    <?php include "../templates/footer.php"; ?>

    <script>
    document.querySelectorAll('.remove-bookmark').forEach(button => {
        button.addEventListener('click', function () {
            let articleUrl = this.getAttribute('data-url');
            fetch('../news/bookmark.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `url=${encodeURIComponent(articleUrl)}`
            }).then(response => response.json()).then(data => {
                if (data.status === "removed") {
                    alert("Bookmark removed!");
                    location.reload();
                }
            });
        });
    });
    </script>
</body>
</html>
