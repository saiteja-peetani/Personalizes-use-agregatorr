<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="../admin/dashboard.php">🛠️ Admin Panel</a>
        <div class="collapse navbar-collapse">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="../admin/manage_users.php">👥 Manage Users</a></li>
                <li class="nav-item"><a class="nav-link" href="../admin/manage_articles.php">📰 Manage Articles</a></li>
                <li class="nav-item"><a class="nav-link btn btn-danger" href="../auth/logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>
