<?php
include "../config/config.php";
if (isset($_POST["update"])) {
    $id = $_POST["id"];
    $title = $_POST["title"];
    $content = $_POST["content"];
    $conn->query("UPDATE articles SET title='$title', content='$content' WHERE id=$id");
    header("Location: manage_articles.php");
}
$id = $_GET["id"];
$result = $conn->query("SELECT * FROM articles WHERE id=$id");
$article = $result->fetch_assoc();
?>
<form method="POST">
    <input type="hidden" name="id" value="<?= $article['id'] ?>">
    <input type="text" name="title" value="<?= $article['title'] ?>" required>
    <textarea name="content"><?= $article['content'] ?></textarea>
    <button type="submit" name="update">Update</button>
</form>
