<?php
include "../config/config.php";
$result = $conn->query("SELECT id, title FROM articles");

echo "<h2>Articles</h2>";
echo "<table border='1'><tr><th>ID</th><th>Title</th><th>Action</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['title']}</td>
        <td>
            <a href='edit_article.php?id={$row['id']}'>Edit</a> | 
            <a href='delete_article.php?id={$row['id']}'>Delete</a>
        </td>
    </tr>";
}
echo "</table>";
?>
