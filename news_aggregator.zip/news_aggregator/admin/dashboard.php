<?php
session_start();
if (!isset($_SESSION["admin_id"])) {
    header("Location: login.php");
    exit();
}
?>
<h2>Admin Dashboard</h2>
<ul>
    <li><a href="manage_users.php">Manage Users</a></li>
    <li><a href="manage_articles.php">Manage Articles</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>
