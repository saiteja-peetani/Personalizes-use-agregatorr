<?php
include "../config/config.php";
if (isset($_GET["id"])) {
    $conn->query("DELETE FROM users WHERE id=" . $_GET["id"]);
    header("Location: manage_users.php");
}
?>
