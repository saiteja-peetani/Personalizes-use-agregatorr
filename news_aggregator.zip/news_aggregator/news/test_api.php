<?php
$apiKey = "6f55944d742e444ab4568b7297901c7c"; // Replace with your key
$apiUrl = "https://newsapi.org/v2/top-headlines?country=us&apiKey=" . $apiKey;

$response = file_get_contents($apiUrl);

if (!$response) {
    die("❌ API request failed!");
}

// Display response
echo "<pre>";
print_r(json_decode($response, true));
echo "</pre>";
?>
