<?php
session_start();
include '../config/db.php';

// Ensure user is logged in before showing news
if (!isset($_SESSION['user_id'])) {
    header("Location: ../auth/login.php");
    exit();
}

$apiKey = "6f55944d742e444ab4568b7297901c7c"; // Your API Key
$apiUrl = "https://newsapi.org/v2/top-headlines?country=us&pageSize=9&apiKey=" . $apiKey;

// Fetch News using cURL
function fetchNews($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Ignore SSL errors for localhost
    curl_setopt($ch, CURLOPT_USERAGENT, 'NewsAggregator/1.0'); // Set User-Agent
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        die("<div class='alert alert-danger text-center'>
            ❌ Failed to load news. API Error (Code: $httpCode)
        </div>");
    }
    return $response;
}

// Get and decode news data
$response = fetchNews($apiUrl);
$newsData = json_decode($response, true);

// Check for errors in API response
if (!$newsData || $newsData['status'] !== 'ok') {
    die("<div class='alert alert-danger text-center'>
        ❌ API Error: " . ($newsData['message'] ?? 'Unknown error') . "
    </div>");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Aggregator</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .news-card {
            height: 100%;
        }
    </style>
</head>
<body>

    <!-- ✅ Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">📰 News Aggregator</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="../auth/logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- ✅ News Section -->
    <div class="container mt-4">
        <h2 class="text-center mb-4">📰 Latest News</h2>
        <div class="row">
            <?php foreach ($newsData['articles'] as $article): ?>
                <div class="col-md-4 mb-3">
                    <div class="card news-card">
                        <img src="<?= $article['urlToImage'] ?: 'https://via.placeholder.com/300' ?>" class="card-img-top" alt="News Image">
                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($article['title']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars(substr($article['description'], 0, 100)) ?>...</p>
                            <a href="<?= $article['url'] ?>" class="btn btn-primary" target="_blank">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- ✅ Bootstrap Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
