<?php
session_start();
include "../config/db.php"; // Database connection

if (!isset($_SESSION['user_id'])) {
    die(json_encode(["status" => "error", "message" => "User not logged in"]));
}

$user_id = $_SESSION['user_id'];
$title = $_POST['title'] ?? '';
$url = $_POST['url'] ?? '';
$image = $_POST['image'] ?? '';
$source = $_POST['source'] ?? '';

if (empty($title) || empty($url) || empty($image) || empty($source)) {
    die(json_encode(["status" => "error", "message" => "Missing required fields"]));
}

// Check if the article is already bookmarked
$checkQuery = $conn->prepare("SELECT id FROM bookmarks WHERE user_id = ? AND article_url = ?");
$checkQuery->bind_param("is", $user_id, $url);
$checkQuery->execute();
$result = $checkQuery->get_result();

if ($result->num_rows > 0) {
    // Remove bookmark if it already exists
    $deleteQuery = $conn->prepare("DELETE FROM bookmarks WHERE user_id = ? AND article_url = ?");
    $deleteQuery->bind_param("is", $user_id, $url);
    $deleteQuery->execute();
    die(json_encode(["status" => "removed", "message" => "Bookmark removed"]));
}

// Insert new bookmark
$insertQuery = $conn->prepare("INSERT INTO bookmarks (user_id, article_title, article_url, article_image, article_source) VALUES (?, ?, ?, ?, ?)");
$insertQuery->bind_param("issss", $user_id, $title, $url, $image, $source);

if ($insertQuery->execute()) {
    die(json_encode(["status" => "added", "message" => "Bookmark added successfully"]));
} else {
    die(json_encode(["status" => "error", "message" => "Failed to add bookmark"]));
}
?>
